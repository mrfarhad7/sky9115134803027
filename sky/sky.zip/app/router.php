<?php

	class router extends controller
	{

		public static function GET ($url , $mask=null  , $callback=null  )
		{
			if ( parent::$_method!=__FUNCTION__ ) return false;
			$p=strpos($url , ':');

			if ($p===false)
			{

				if (parent::$_url[1]==$url and empty(parent::$_url[2]))
				{

					if ($mask!=null)
					{
						$url=$mask;
						parent::$_url[1]=$mask;
					}
					parent::start($url);
				}

			}
			else
			{


				$_url=explode(":",$url);
				if (parent::$_url[1]==$_url[0])
				{

					$params = substr($url,++$p,strlen($url)) ;
					$ul = strlen($url) - strlen($params);
					$params = explode( "%" , $params );
					$index=count($params);
					if (!empty(parent::$_url[$index]))
					{
						if (empty(parent::$_url[++$index]))
						{
							for ($i=2 ; $i<=count($params) ; $i++)
							{
								$vars[$i]=parent::$_url[$i];
							}
							$url=substr($url,0,--$ul);

							parent::start($url,$vars);
						}
					}
				}

			}
			if ($callback!=null) $callback();

		}

		public static function POST ( $function , $data , $callback=null )
		{

			if ( parent::$_method==__FUNCTION__ )
			{

				if ( isset ($_POST['function']) )
				{
					$function_post = core::decrypt($_POST['function'],0);
					if ( $function == $function_post )
					{
						require_once __FUNCTION__.".class.php";
						post::run($function , $data , $_POST , $callback);
					}
				}
			}

		}

	}

?>
