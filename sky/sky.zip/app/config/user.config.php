<?php

return array (

"site_title" => "invoice system",
"siteName" => " سیستم فاکتور دهی",
"phone"=>" (+98) 936 911 3027",
"invoice"=> array (
  "title"=>"فروش"
),
"units" => array  (
    "kg" => "کیلوگرم",
    "g"=>"گرم",
    "m"=>"متر",
    "cm"=>"سانتی متر",
    "m2"=>"متر مربع",
    "cm2"=>"سانتی متر مربع",
    "km2"=>"کیلومتر مربع",
    "hektar"=>"هکتار",
    "cc"=>"سی سی",
    "liter"=>"لیتر",
    "number"=>"عدد",
    "box"=>"بسته"
  )
)



/*
  new page blank
  <?php require "header.view.php" ?>
  <div class="col-md-12 bootstrap-grid" style="text-align:right">
  <div class="powerwidget blue"  >
       <header>
        لیست پروژه ها
       </header>
       <div>

       </div>
   </div>
  </div>
*/


?>
