<?php
return array(

	'valid_exts' => 
	  array (
		0 => 'jpg',
		1 => 'jpeg',
		2 => 'pptx',
		3 => 'png',
		4 => 'zip',
		5 => 'pdf',
		6 => 'ppt',
	  )


);
?>