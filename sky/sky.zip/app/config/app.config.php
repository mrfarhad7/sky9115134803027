<?php

	define('siteurl' , 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT']);

	define('view_url', siteurl.'/app/views');

	define('controller_path', $_SERVER['DOCUMENT_ROOT'].'/app/controllers');

	define('view_path', $_SERVER['DOCUMENT_ROOT'].'/app/views');

	define('model_path', $_SERVER['DOCUMENT_ROOT'].'/app/models');

	define('daily_limit' , 26);

	define('hourly_limit' , 8);

	define('time_format1','  Y/m/d');

	define('time_format2','  Y/m/d H:i:s');

	define('style','default');

	define('style_path', view_url.'/style.'.style );

	define('_style_path', app_path.'/app/views/style.'.style );

?>
