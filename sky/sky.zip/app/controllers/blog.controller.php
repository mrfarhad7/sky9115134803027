<?php

	
	class blog_controller extends controller
	{
		
		protected static $_method;
		protected static $_url;
		protected static $_data;
		protected static $_login = 'default' ;
		
		public function __construct($data=null)
		{
			self::$_method=parent::$_method;
			self::$_url=parent::$_url;
			if ($data!=null) self::$_data=$data;

				self::start();

		}
		
		public static function start($route=null,$data=null)
		{
			if (empty(self::$_data))
			{

				Error::show(__CLASS__ ." params not defined !");
				
			}
			else
			{
				
				$model = new model ('blog',self::$_data[2],
				
					function($data){
						
						$view = new view ('blog' , $data );
						
					});
				
			}

		}
		
	}

?>