<?php


class controller {

	protected static $_method;
	protected static $_url;
	public static $name;
	public function __construct()
	{

		self::$_method=$_SERVER['REQUEST_METHOD'];
		self::$_url=explode('/',$_SERVER['REQUEST_URI']);

		require app_path."/app/routerlist.php" ;

	}

	public static function start($route,$data=null)
	{
		self::$name=$route;
		$ControllerName=$route;
		if ( empty ( self::$_url[1] ) )
		{
			$ControllerName="home";
		}
			$controller = controller_path."/$ControllerName.controller.php";
			if (file_exists($controller))
			{
				require $controller	;
				$ControllerName.="_controller";
				$controller = new $ControllerName($data);
			}
			else
			{
				Error::show(__CLASS__ , "$ControllerName controller not found !");
			}


	}
}


?>
