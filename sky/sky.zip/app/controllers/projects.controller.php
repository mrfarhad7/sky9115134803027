
<?php

	class projects_controller extends controller
	{

		protected static $_method;
		protected static $_url;
		protected static $_data;
		protected static $_login ="user";
		public function __construct($data=null)
		{
			self::$_method=parent::$_method;
			self::$_url=parent::$_url;
			if ($data!=null) self::$_data=$data;

				
			$login=new login(self::$_login);
			if ( $login::check() )

				self::start();

				else
					core::url("/login");
		}

		public static function start($route=null,$data=null)
		{
			if ( empty ( self::$_data ) )
			{

				
			$model = new model ("projects",self::$_data,

					function($data){

						$view = new view ("projects" , $data );

					});
		

			}
		}

	}

?> 