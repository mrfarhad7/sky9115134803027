<?php

	$sql = new database;
	$sql->insert_new('ideas','');
	$sql->select('ideas','1',1);
	$i=0;$ideas="";
	while($row=$sql->result->fetch_assoc())
	{
		$ideas[$i++]=$row['id'];	
	}
	return $ideas;
	

?>