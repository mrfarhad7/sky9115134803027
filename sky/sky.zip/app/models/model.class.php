<?php

	class model
	{
		
		public function __construct($model,$data,$callback)
		{
			$modelfile= model_path."/$model.model.php";
			if (file_exists($modelfile))
			{
				$model_data=require $modelfile;
				$callback($model_data);
			}
			else 
			{
				Error::show( __CLASS__ , "$model model not found !");
			}
			
			
		}
		
		
		
		
		
	}

?>
