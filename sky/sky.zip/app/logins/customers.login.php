<?php

class customers_login extends login
{


	public function __construct()
	{
		if ( isset ( $_SESSION[__CLASS__] ) )
		$this->is_login=$_SESSION[__CLASS__];
		else {
			$this->is_login=false;
		}
	}
	public static function start($user , $pass)
	{

		$encrypted=core::encrypt($pass,":)");
		$c2db=database::create_connection();
		$sql="CALL `customers` ('$user','$encrypted');";
		$result=$c2db->query($sql);
		$row=$result->fetch_assoc();
		$access=$row['access'];
		$result=$c2db->next_result();
		if ($access=='1'){
			$_SESSION['userid']=$row['userid'];
			$_SESSION['uname']=$row['uname'];
			$_SESSION['name']=$row['name1'];
			$_SESSION[__CLASS__]=true;
			$_SESSION['user_type']="customers";
		}else{
			return false;
		}
	}
	public static function logout()
	{
		unset( $_SESSION[__CLASS__] )	;
		unset( $_SESSION['userid']  )  ;
		unset($_SESSION['user_type']);

	}


}
