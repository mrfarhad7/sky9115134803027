<?php

class login
{
	protected static $_login;

	public function __construct( $login )
	{
		$r=stripos($login,"/");
		if (!is_numeric($r))
		{
			$r=stripos($login,".ini");
			if (!is_numeric($r))
			{
				$r=stripos($login,"http");
				if (!is_numeric($r))
				{
			self::$_login=$login;
			require_once self::$_login.'.login.php' ;
			self::$_login.='_login';
			self::$_login=new self::$_login();
		}}
		}
		else
		{
			die();
		}
	}
	static function check()
	{

		return self::$_login->is_login;

	}
	static function start($user , $pass)
	{
		$login=self::$_login;
		$login::start($user , $pass);

	}
	static function logout()
	{
		$login=self::$_login;
		$login::logout();
	}
	static function data()
	{
		$login=self::$_login;
		return $login::data();
	}

}



?>
