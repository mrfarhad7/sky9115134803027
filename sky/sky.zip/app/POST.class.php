<?php

class post
{
	public static function run( $function , $data , $POST ,$callback=null)
	{
		$log=fopen("log/postlog.lg","a+");
		fwrite($log,date("Y-m-d H:i:s")." function=$function  post_data=".implode($_POST,"  ")."\r\n");
		fclose($log);
		$valid_exts =
		  array (
			 'jpg',
			 'jpeg',
			 'pptx',
			 'png',
			 'zip',
			 'pdf',
			 'ppt'
		  );
		self::$function( $data , $POST , $callback);

	}





	protected static function login($name , $POST , $callback=null)
	{
		$usertype=$POST['user_type'];
		$user=$POST['user'];
		$pass=$POST['pass'];
		$login=new login($usertype );
		$login::start($user , $pass);

		if ($callback!=null) $callback();

	}




	protected static function logout($name , $POST , $callback=null)
	{

		$usertype=$POST['user_type'];
		$login=new login($usertype );
		$login::logout();
		if ($callback!=null) $callback();

	}

	protected static function loginadmin($name , $POST , $callback=null)
	{
		$user=$POST['user'];
		$pass=$POST['pass'];
		$login=new login($name );
		$login::start($user , $pass);
		if ($callback!=null) $callback();

	}
	protected function logoutadmin($name , $POST , $callback=null)
	{
		$login=new login($name );
		$login::logout();
		if ($callback!=null) $callback();

	}
	protected static function delete_file($name , $POST , $callback=null)
	{
		$filename=$POST['filename'];
		$filename=explode("/",$filename);
		$filename=$filename[count($filename)-1];
		$filepath=app_path.'/files/'.$filename;
		if (file_exists($filepath))
		unlink($filepath);
		$sql = new database;
		$sql->delete('files',$POST['id']);

	}
	protected static function upload($name , $POST , $callback=null)
	{
		$name=$POST['name'];
		$comment=$POST['comment'];
		$time=time();
		$target_file = ($_FILES["file"]["name"]);
		$url='/files/'.$target_file;

		move_uploaded_file($_FILES["file"]["tmp_name"], app_path.'/files/'.$target_file);
		$sql=new database;
		$insert_data="(`id`, `name`, `url`, `downloads`, `comment`, `time`) VALUES
		(NULL, '$name', '$url', '0', '$comment', '$time');";
		$sql->insert_new('files',$insert_data);
		if ($callback!=null) $callback();

	}
	protected static function contact($name , $POST ,$callback=null)
	{
		$name=$POST['name'];
		$email=$POST['e-mail'];
		$phone=$POST['phone'];
		$subject=$POST['subject'];
		$message=$POST['message'];
		$time=time();
		$sql=new database;
		$insert_data="(`id`, `subject`, `name`, `email`, `phone`, `message`, `time`) VALUES
		(NULL, '$subject', '$name', '$email', '$phone', '$message', '$time');";
		$sql->insert_new('messages',$insert_data);
		if ($callback!=null) $callback();

	}
	protected static function change_password($name , $POST , $callback=null)
	{
		$pass=core::encrypt($_POST['pass']);
		$sql=new database;
		$sql->edit('users',1,array('id','password'),array(1,$pass),1);
		echo 101;
		if ($callback!=null) $callback();

	}




	protected static function delete($name , $POST , $callback=null)
	{
		$id=$POST['id'];
		$table=$POST['type'];
		$sql=new database;
		$sql->delete($table,$id);
		if ($callback!=null) $callback();

	}


	protected static function response($msgheader , $msg , $urlBack)
	{
		$_SESSION[__FUNCTION__.'msgheader']=$msgheader;
		$_SESSION[__FUNCTION__.'msg']=$msg;
		$_SESSION[__FUNCTION__.'url']=$urlBack;
	}


	protected function forgotpassword($name , $POST , $callback=null)
	{
		$_SESSION['res']=true;
		$_SESSION['res_msgheader']="فراموشی اطلاعات کاربری";
		$_SESSION['res_url']=siteurl;
		$sql = new database;
		$sql->select('users','email','"'.$POST['email'].'"');
		$row=$sql->result_sl->fetch_assoc();
		if (!empty($row))
		{
			$user=$row['username'];
			$pass=core::decrypt($row['password'],":)");
			$message = "username : $user <br> password : $pass";
			mailsys::send($POST['email'],"",$message,"- اطلاعات کاربری",$row['fname']."  ".$row['lname']);
			$_SESSION['res_msg']="اطلاعات کاربری به ایمیل شما ارسال گردید";
		}else
		{
			$_SESSION['res_msg']="ایمیل وارد شده صحیح نمی باشد";
		}
		if ($callback!=null) $callback();
	}
}

?>
