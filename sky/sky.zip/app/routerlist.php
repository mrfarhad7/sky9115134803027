
<?php


	/*GET*/
router::GET("projects:%p1");
router::GET("");
        /*POST*/
 /* new line */ router::POST("signup","",function($res){core::url($res);}); /* new line */ router::POST("signup","",function($res){core::url($res);}); /* new line */ router::POST("signup","",function($res){core::url($res);}); /* new line */ router::POST("signup","",function($res){core::url($res);});
?>
