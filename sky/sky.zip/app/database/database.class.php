<?php
class database {

	protected static $_connection = NULL;
	public static function create_connection(){

		if (!self::$_connection) {
			 self::$_connection = @new mysqli(db_host, db_user, db_pass, db_name);
				mysqli_set_charset(self::$_connection,'utf-8');
				mysqli_query(self::$_connection , "set names 'utf8'" );
				 if (self::$_connection -> connect_error) {
					die('Connect Error: ' . self::$_connection->connect_error);
				 }
			  }
		return self::$_connection;
	}
	protected $mlink;
	public static $mysqli_link;
	public $numrow;
	public $result;
	public $record,$data;
	public $close_mysqli=false;
	public function __construct()
	{

		$this->mlink=self::create_connection();
		database::$mysqli_link=$this->mlink;
	}

	public function __destruct()
	{
		$this->close_link();
	}
	public static function close_connection()
	{
		mysqli_close(self::$mysqli_link);
	}
	public function close_link()
	{
		if ($this->close_mysqli)
		mysqli_close($this->mlink);
	}
	public function numrow($table,$data)
	{
				$mlink=$this->mlink;
				$sql="SELECT id FROM ".$table. " WHERE ".$data;
				$result0=$mlink->query($sql);
				if (!empty($result0))
				{
					$row_cnt = $result0->num_rows;
					$this->numrow=$row_cnt;
				}
	}

	public function select($table,$record,$data,$limit=null,$sort=null)
	{
				$mlink=$this->mlink;
				$sql= 'SELECT * FROM '.$table.' where '.$record.'= '.$data;
				if ($limit!=null) $sql.=$limit;
				if ($sort!=null) $sql.=$sort;
				if (!($result=$mlink->query($sql)))
				{
					Error::show ( __CLASS__ , mysqli_error($mlink) );
					return false;
				}
				else
				{
					$this->result=$result;
				}
	}
	public function search($table,$select,$record,$data)
	{
				$mlink2=$this->mlink;
				$sql2= 'SELECT '.$select.' FROM '.$table.' where `'.$record.'` LIKE "%'.$data.'%" ;';
				$result2=$mlink2->query($sql2);
				$this->result_sl=$result2;
	}
	public function delete($table,$datadl)
	{
				$mlink3=$this->mlink;
				$sql3= "DELETE FROM ".$table." WHERE id = ".$datadl." ";
				$result3=$mlink3->query($sql3);
	}
	public function delete_wp($table,$record,$datadl)
	{
				$mlink3=$this->mlink;
				$sql3= "DELETE FROM ".$table." WHERE ".$record." = ".$datadl." ";
				$result3=$mlink3->query($sql3);
	}
	public function edit($table,$array_end,$record_array,$data_array,$where)
	{
				$mlink4=$this->mlink;
				for($i=1;$i<=$array_end;$i++){
					$sql4= "UPDATE ".$table." SET ".$record_array[$i]."='".$data_array[$i]."' WHERE `id` = ".$where."";
					$result4=$mlink4->query($sql4);
				}
	}
	public function edit_wp($table,$array_end,$record_array,$data_array,$where)
	{
				$mlink4=$this->mlink;
				for($i=0;$i<=$array_end;$i++){
					$sql4= "UPDATE ".$table." SET ".$record_array[$i]."='".$data_array[$i]."' WHERE ".$where."";
					$result4=$mlink4->query($sql4);
				}
	}
	public function insert($table,$data)
	{
				$mlink5=$this->mlink;
				$sql5= "INSERT INTO ".$table." ".$data." ;";
				if (!($result5=$mlink5->query($sql5)))
				{
					Error::show ( __CLASS__ , mysqli_error($mlink5) );
					return false;
				}
				return($mlink5->insert_id);
	}
	public function auto_i($table)
	{
		$sql=$this->mlink;
		$data=$sql->query("show table status like '".$table."' ");
		$row=$data->fetch_assoc();
		return $row['Auto_increment'];
	}

}


?>
