<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2012 - Sky framework </p>
    <p class="fl_right">Developed By  <a href="http://farhad-m.ir/" title="Farhad Mehryari">Farhad Mehryari</a></p>
  </footer>
</div>
</body>
</html>
