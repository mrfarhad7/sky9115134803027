<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Sky</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="<?php echo style_path ?>/styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
