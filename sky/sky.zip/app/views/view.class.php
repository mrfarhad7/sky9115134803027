<?php

	class view
	{

		public function __construct( $view , $data ,  $_style=null)
		{

			global $vars,$_view;
			$vars=$data;
			$_view=$this;
			$style=style;
			if ($_style!=null) $style=$_style;
			$viewfile=view_path."/style.".$style."/"."$view.view.php";
			$headerfile=view_path."/style.".$style."/"."header.view.php";
			$footerfile=view_path."/style.".$style."/"."footer.view.php";
			if (!file_exists($headerfile)) $headerfile=view_path."/style.default/header.view.php";
			if (!file_exists($footerfile)) $footerfile=view_path."/style.default/footer.view.php";
			if ($view=="home" && !file_exists($viewfile)) $viewfile=view_path."/style.default/home.view.php";
			if (file_exists($viewfile))
			{

				require $headerfile;
				require $viewfile;
				require $footerfile ;

			}
			else
			{
				Error::show(__CLASS__ , "$view view not found !");
			}



		}

		protected function cache ($view,$data)
		{
			global $vars,$_view;
			$vars=$data;
			$_view=$this;
			$file = app_path."/cache/$view.view";
			$cachefile = $file.".cached.php";
			$cachetime = 18000;
			if (file_exists($cachefile) && time() - $cachetime < filemtime($cachefile))
			{
				echo "<!-- Cached copy, generated ".date('H:i', filemtime($cachefile))." -->\n";
				include($cachefile);
				exit;
			}

			ob_start();
			require "$view.view.php" ;
			$content = ob_get_contents();
			$cached = fopen($cachefile, 'w');
			fwrite($cached,$content);
			fclose($cached);
			ob_flush();
		}

	}

?>
