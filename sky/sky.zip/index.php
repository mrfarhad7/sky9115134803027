<?php

	session_start();

	ini_set('display_errors', 1);
	error_reporting(E_ALL | E_STRICT);

	define( "app_path" , dirname (__FILE__)) ;
	define( "ICE" , true );

	require "init.php"	;
	$controler = new controller;

	//database::close_connection();

?>
