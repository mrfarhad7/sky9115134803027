<?php

	class core
	{

		static function loadlib( $name , $type )
		{
			switch( $type )
			{
				case 'php' :
					return include app_path.'/libs/'.$type.'/'.$name.'.'.$type ;break;

				case 'js'  :
					echo "<script src='".siteurl."/libs/$type/$name.$type'></script>";break;

				case 'css' :
					echo "<link href='".siteurl."/libs/$type/$name.$type'></link>";break;
			}

		}
		static function array_swap_assoc($key1, $key2, $array) {
				$newArray = array ();
				foreach ($array as $key => $value) {
						if ($key == $key1) {
								$newArray[$key2] = $array[$key2];
						} elseif ($key == $key2) {
								$newArray[$key1] = $array[$key1];
						} else {
								$newArray[$key] = $value;
						}
				}
				return $newArray;
		}
		static function url ( $url=null )
		{

			header("location: ".siteurl.$url);

		}

		static function encrypt($text, $salt=null)
		 {
			 if ($salt==null) $salt="3zrlyo33cq92e01z";
			return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $salt, $text, MCRYPT_MODE_ECB,
			 mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));

		}


		static function decrypt($text, $salt=null)
		{
			 if ($salt==null) $salt="3zrlyo33cq92e01z";
			return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $salt, base64_decode($text), MCRYPT_MODE_ECB,
			 mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));

		}

		static function POST($url, $data, $optional_headers = null)
		{
		  $url=siteurl.$url;
		  $params = array('http' => array(
					  'method' => 'POST',
					  'content' => $data
					));
		  if ($optional_headers !== null) {
			$params['http']['header'] = $optional_headers;
		  }
		  $ctx = stream_context_create($params);
		  $fp = @fopen($url, 'rb', false, $ctx);
		  if (!$fp) {
			throw new Exception("Problem with $url, $php_errormsg");
		  }
		  $response = @stream_get_contents($fp);
		  if ($response === false) {
			throw new Exception("Problem reading data from $url, $php_errormsg");
		  }
		  return $response;
		}
	}
	class config
	{

		public static function load($name,$index=null)
		{
			if (!isset($name)) return false;
			$config=require app_path."/app/config/".$name.".config.php";
			if ($index!=null) return $config[$index];
			return $config;
		}
	}
		class sms
	{

		public static function getcredit()
		{

			$postdata=array('function'=>'getcredit','user'=>'tabrizidea.ir');
			return core::post(sms_service_url,array('function'=>'getcredit','user'=>'tabrizidea.ir'));
		}

		private static function smsaccount()
		{
			$postdata=array('function'=>'getaccount','user'=>'tabrizidea.ir');
			$smsaccount = core::post(sms_service_url,$postdata);
			return explode(",",$smsaccount);
		}

		public static function send($to,$message)
		{
			$credit=sms::getcredit();

			if ($credit>=1)
			{
				$smsaccount = sms::smsaccount();
				$data=array(
					"user"=>$smsaccount["0"],
					"pass"=>$smsaccount["1"],
					"lineNo"=>$smsaccount["2"],
					"to"=>$to,
					"text"=>$message
				);
				$url="http://n.sms.ir/SendMessage.ashx?".http_build_query($data);

				$resp = file_get_contents($url);

				$postdata=array(
					'function'=>'setcredit',
					'user'=>'tabrizidea.ir',
					'credit'=>--$credit
				);
				core::post(sms_service_url,$postdata);
			}

		}

	}

	class mailsys
	{

		public static function send($to,$from,$message,$subject,$name)
		{


			$headers = "From: " . strip_tags($from) . "\r\n";
			$headers .= "Reply-To: ". strip_tags($from) . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

			$message = '<html><body>';
			$message .= '<img src="'.siteurl.'/app/views/images/home/logo.png"  />';
			$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
			$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>". strip_tags($name) ."</td></tr>";
			$message .= "<tr><td><strong>Email:</strong> </td><td>". strip_tags($from) ."</td></tr>";
			$message .= "<tr><td><strong>Subject:</strong> </td><td>" . strip_tags($subject) . "</td></tr>";
			$message .= "<tr><td><strong>Message:</strong> </td><td>" . htmlentities($message) . "</td></tr>";
			$message .= "</table>";
			$message .= "</body></html>";

			mail($to, $subject, $message, $headers);

		}

	}
	class Error
	{
	public static function show($type , $message)
	{
		echo
		'
			<meta charset="UTF-8"/><link rel="stylesheet" href="'.siteurl.'/libs/css/error.css">
		';
		echo "<div id='console'><pre><b>$type</b> : $message</pre></div>";
		die();
	}


	}


?>
