<form method="post" style="max-width:800px;padding:30px">
name : <input type="text" name="name" ><br>
is ajax :
<select  name="is_ajax" >
  <option value="0">No </option>
  <option value="1">Yes </option>
</select><br>
callback function : <textarea  name="callback" ></textarea><br>
posted values : <textarea  name="values" ></textarea><br>
<input type="submit" value="create function" name="cp">
</form>










<?php
define ( 'app_path' , substr( __DIR__ , 0 , (strlen(__DIR__)-4) ));
require app_path.'\core.class.php';
if (isset($_POST['cp']))
{
  $name=$_POST['name'];
  echo "
  <
  input type='hidden' name='function' value='".core::encrypt($name)."'
  >";
  $dataf='""';
  if (!$_POST['is_ajax'])
  {
    $dataf='"",function($res){'.$_POST['callback'].'}';
  }
  $routerlistfile=app_path.'\app\routerlist.php';
		$lines = array();		$index=0;
		foreach(file($routerlistfile) as $indx=>$line)
		{
			if('/*POST*/' == trim($line))
			{
				$index=$indx+1;
        array_push($lines, '  ');
				array_push($lines, 'router::POST("'.$name.'",'.$dataf.');');
        array_push($lines, ' /* new line */ ');
			}
			array_push($lines, $line);
		}
    print_r($lines);
		$lines = array_swap_assoc($index, $index+2, $lines);
    print_r($lines);
		file_put_contents($routerlistfile, $lines);
    
    print_r($lines);
}










function array_swap_assoc($key1, $key2, $array) {
		$newArray = array ();
		foreach ($array as $key => $value) {
				if ($key == $key1) {
						$newArray[$key2] = $array[$key2];
				} elseif ($key == $key2) {
						$newArray[$key1] = $array[$key1];
				} else {
						$newArray[$key] = $value;
				}
		}
		return $newArray;
}
?>
