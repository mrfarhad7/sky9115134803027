<form method="post" style="max-width:800px;padding:30px">
controller : <input type="text" name="name" ><br>
url allowed parameters : <input type="number" name="uap" ><br>
mask : <input type="text" name="mask" ><br>
if need model : <input type="text" name="model" ><br>
if need login : <input type="text" name="login" ><br>
view if not equal with controller : <input type="text" name="view" ><br>
<input type="submit" value="create page" name="cp">
</form>










<?php
define ( 'app_path' , substr( __DIR__ , 0 , (strlen(__DIR__)-4) ));
if (isset($_POST['cp']))
{
	$name=$_POST['name'];
	$uap=$_POST['uap'];
	$login_name="";
	$login_data="self::start();";
	$view=$_POST['name'];
	$model='$view = new view("'.$view.'","");';
	if (!empty($_POST['view']))
	{
		$view=$_POST['view'];
	}
	if (!empty($_POST['login']))
	{
		$login_name=$_POST['login'];
		$login_data='
			$login=new login(self::$_login);
			if ( $login::check() )

				self::start();

				else
					core::url("/login");';
	}
	if (!empty($_POST['model']))
	{
		$model='
			$model = new model ("'.$_POST['model'].'",self::$_data,

					function($data){

						$view = new view ("'.$view.'" , $data );

					});
		';

		$_POST['model'];
	}
	$controller_data=
'
<?php

	class '.$name.'_controller extends controller
	{

		protected static $_method;
		protected static $_url;
		protected static $_data;
		protected static $_login ="'.$login_name.'";
		public function __construct($data=null)
		{
			self::$_method=parent::$_method;
			self::$_url=parent::$_url;
			if ($data!=null) self::$_data=$data;

				'.$login_data.'
		}

		public static function start($route=null,$data=null)
		{
			if ( empty ( self::$_data ) )
			{

				'.$model.'

			}
		}

	}

?> ';
	$controller=fopen(app_path."/app/controllers/".$name.".controller.php","r+");
	fwrite($controller,$controller_data);
	fclose($controller);
	$viewfile=fopen(app_path."/app/views/style.default/".$view.".view.php","r+");
	fwrite($viewfile,"");
	fclose($viewfile);
	if (!empty($_POST['model']))
	{
		$modelfile=fopen(app_path."/app/models/".$_POST['model'].".model.php","r+");
		fwrite($modelfile,"");
		fclose($modelfile);
	}
	$routerlistfile=app_path.'\app\routerlist.php';

		$lines = array();		$index=0;
		foreach(file($routerlistfile) as $indx=>$line)
		{
			if('/*GET*/' == trim($line))
			{echo "asd";
				$index=$indx;
				array_push($lines, 'router::GET("'.$name.'");');
			}
			array_push($lines, $line);
		}
		$lines = array_swap_assoc($index, ++$index, $lines);
		file_put_contents($routerlistfile, $lines);
		if ($uap>0)
		{
			$params="";
			for($j=1;$j<=$uap;$j++)
			$params.="%p$j";
			var_dump($params);
			$lines = array();			$index=0;
			foreach(file($routerlistfile) as $indx=>$line)
			{
				if('/*GET*/' == trim($line))
				{
					$index=$indx;
					array_push($lines, 'router::GET("'.$name.':'.$params.'");');
				}
				array_push($lines, $line);
			}
			$lines = array_swap_assoc($index, ++$index, $lines);
			file_put_contents($routerlistfile, $lines);
	}

}






function array_swap_assoc($key1, $key2, $array) {
		$newArray = array ();
		foreach ($array as $key => $value) {
				if ($key == $key1) {
						$newArray[$key2] = $array[$key2];
				} elseif ($key == $key2) {
						$newArray[$key1] = $array[$key1];
				} else {
						$newArray[$key] = $value;
				}
		}
		return $newArray;
}
?>
