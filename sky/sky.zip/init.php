<?php

	defined("ICE") or die();

	require_once app_path."/app/config/app.config.php" ;

	require_once app_path."/app/config/database.config.php" ;

	require_once app_path."/app/database/database.class.php";

	require_once app_path."/app/logins/login.class.php" ;

	require_once app_path."/core.class.php" ;

	core::loadlib("persianc","php");

	core::loadlib("jcalendar","php");

	core::loadlib("mailer/mailer","php");

	require_once app_path."/app/controllers/base.controller.php" ;

	require_once app_path."/app/router.php" ;

	require_once app_path."/app/views/view.class.php" ;

	require_once app_path."/app/models/model.class.php" ;


?>
